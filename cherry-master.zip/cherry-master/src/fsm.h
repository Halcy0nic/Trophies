#ifndef FSM_H
#define FSM_H

typedef enum {
    STATE_EMPTY = 0,
    STATE_NONEMPTY
} state_t;

#endif
