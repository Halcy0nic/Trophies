#ifndef _ARPA_INET_H_
#define _ARPA_INET_H_

#include <stdint.h>

uint32_t htonl(uint32_t hostlong);
uint16_t htons(uint16_t hostshort);

#endif
