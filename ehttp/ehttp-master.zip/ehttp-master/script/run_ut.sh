test_dir="./output/test"
$test_dir/threadpool_test
$test_dir/sim_parser_test
$test_dir/string_utils_test
$test_dir/simple_config_test
$test_dir/simple_log_test
$test_dir/epoll_socket_test
$test_dir/http_server_test
