
test(X,Y) :-
    X is sin(1)+cos(2),
    Y =.. [sin,3].

