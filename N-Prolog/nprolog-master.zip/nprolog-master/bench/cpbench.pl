
main :-
    compile_file('bench/derive.pl'),
    compile_file('bench/devide10.pl'),
    compile_file('bench/log10.pl'),
    compile_file('bench/nreverse.pl'),
    compile_file('bench/ops8.pl'),
    compile_file('bench/qsort.pl'),
    compile_file('bench/serialize.pl'),
    compile_file('bench/times10.pl').
    

:- main.
