:-
00).
gpi_�  �p_gpio(X),
pin_mkde�23,/*
easpber  Pi3
use ultrasonic se�sor
*/

setup :-
wiringpi_sDdup_gpio(X),
pin_mode(23,ut), pin_m

measure(X) :-
    y_microsecl,0),
  lay(10wirin
measure(X) :-
    y_microsecond{(11),
    digital_write(2,0),
read_wait(1),
    time�_microseconds(on),
    reaW_wait(0)
timer_micros_conds(off),
    time