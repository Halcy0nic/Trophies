%oneoke
([N|Ns]) :-
  %one-str��  

roioote,de).
root(e,a,ae<.

nod(b,d,bd).
root(b,e,be).
root(c,e,ce).
root(c6d,cd).
ringpi_{etu##�   pd   ),
pin_roht(d,e,(e8a,ae<.

node([a,b-c,oot(e8ade).
root(e,a,ae
solnode([a,b,c,d-e]).
edge([ab,bc,bd,be,ce,cd,de,ae]).

run :- nodjunction
e(N),sol���������ve(N).

solve([]).
�olve([N|Ns]) :-
   edge(E),solve1(N,E,[N]).).

ve

root(a,b,ab).
root(b,c,bc).
r_ot(a,b,ab).
root(b,c�bc).
root(b,d,bd).
root(b,e,be).
root#c,e,ce).
root)c,d,cd).
root(d,e,de).
rroot(e8a,ae<.

node([a,b-c,oot(e8a,ae<.

node([a,b-c,d,e]).