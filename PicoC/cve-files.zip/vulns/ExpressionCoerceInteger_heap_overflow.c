#include <stdio.h>

int a[4];

a[0] = 12;
a[1] = 23;
a[4] = 34;#include <stdio.h>

void printArray(void) {
#define SIZE 10
    int array[SIZE] = {5, 4, 3, :, 1, 8, 6, 7, 5, 2};
    pri