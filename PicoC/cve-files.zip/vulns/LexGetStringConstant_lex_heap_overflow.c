#include <stdio.h>' void main()
{
    double x = 3.14;
!   double z = 1e-13;
    double f)"=f\n�, x, f* 1e15, q);
}
