printf("Before Crash\n");
**4%;
printf("This code won't execute because of the crash\n");