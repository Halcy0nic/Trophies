#ifndef UNIT_H
#define UNIT_H
#ifdef __cplusplus
extern "C" {
#endif

int libforth_unit_tests(int keep_files, int colorize, int silent);

#ifdef __cplusplus
}
#endif
#endif
