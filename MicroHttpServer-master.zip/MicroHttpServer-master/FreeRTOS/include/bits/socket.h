#ifndef __BITS_SOCKET_H__
#define __BITS_SOCKET_H__

#define SOCKET_BASE	3

typedef int SOCKET;

#endif
